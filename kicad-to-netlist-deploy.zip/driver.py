"""Browser driver for SchemAccess.

This module is the only piece of SchemAccess that knows it is running in
a web page.  It is loaded into Pyodide alongside the library and exposes
three functions to JavaScript:

``root_sheet(paths)``
    Pick the top sheet out of a set of uploaded files.  In a hierarchical
    KiCad project every sub-sheet is referenced by a parent, so the root
    is simply the file nobody references.

``convert(path)``
    Run the whole conversion in memory and return one JSON blob holding
    every output -- the drawing, the LaTeX, the four netlists, the three
    description lengths, the statistics and every warning.  Nothing is
    written to disk; the page turns the strings into downloads itself.

``build_zip()``
    Package the outputs of the last :func:`convert` call into a ``.zip``,
    using the standard library so the page needs no archiving script.
    The rendered PDF is added by the page, since LaTeX produces it.

The pipeline module is deliberately *not* used: it writes files and
drives a LaTeX toolchain, neither of which exists in a browser.  The
stages it calls are used directly instead, in the same order, so the
numbers reported here match the ones the desktop tool reports.
"""

from __future__ import annotations

import io
import json
import os
import time
import zipfile

from schemaccess import (alttext, circuitikz, kicad_parser, netbuilder,
                         netlist, pipeline)

__all__ = ["root_sheet", "convert", "build_zip", "version"]

#: Outputs of the most recent successful conversion, kept so the page can
#: ask for a zip without shipping every file back into Python.
_LAST: dict = {}

_MIME = {
    "tex": "application/x-tex",
    "cir": "text/plain",
    "net": "text/plain",
    "txt": "text/plain",
    "csv": "text/csv",
    "svg": "image/svg+xml",
    "pdf": "application/pdf",
}


def version() -> str:
    from schemaccess import __version__
    return __version__


def _stem(path: str) -> str:
    return os.path.splitext(os.path.basename(path))[0]


def root_sheet(paths) -> str:
    """Return the path of the sheet that no other sheet references.

    Falls back to the first path when every candidate is referenced (a
    cycle) or when only one was given.
    """
    # ``paths`` arrives from JavaScript, so coerce before touching it.
    candidates = [str(p) for p in list(paths)
                  if str(p).lower().endswith(".kicad_sch")]
    if not candidates:
        return ""
    if len(candidates) == 1:
        return candidates[0]

    referenced = set()
    for path in candidates:
        try:
            doc = kicad_parser.parse_file(path, resolve_hierarchy=False)
        except kicad_parser.KiCadParseError:
            continue
        for sheet in doc.sheets:
            if sheet.filename:
                referenced.add(os.path.basename(sheet.filename).lower())

    roots = [p for p in candidates
             if os.path.basename(p).lower() not in referenced]
    return sorted(roots or candidates)[0]


def convert(path: str, junction_dots: bool = True) -> str:
    """Convert *path* and return every output as one JSON string."""
    global _LAST
    _LAST = {}

    try:
        started = time.perf_counter()
        doc = kicad_parser.parse_file(path)
    except kicad_parser.KiCadParseError as exc:
        return json.dumps({"ok": False, "error": str(exc)})
    except Exception as exc:                       # never leak a traceback
        return json.dumps({"ok": False,
                           "error": f"Could not read the file: {exc}"})

    graph = netbuilder.build_graph(doc)
    parse_ms = (time.perf_counter() - started) * 1000.0

    started = time.perf_counter()
    fallbacks: set = set()
    tex = circuitikz.generate(graph, junction_dots=junction_dots,
                              fallbacks=fallbacks)
    draw_ms = (time.perf_counter() - started) * 1000.0

    started = time.perf_counter()
    descriptions = {level: alttext.generate(graph, level)
                    for level in pipeline.DETAIL_LEVELS}
    text_ms = (time.perf_counter() - started) * 1000.0


    nets = {}
    notes = {}
    for fmt in netlist.FORMATS:
        result = netlist.generate(graph, fmt)
        nets[fmt] = result.text
        notes[fmt] = result.notes

    stats = pipeline.summarize(graph, tex, descriptions["detailed"],
                               fallbacks)
    stats.parse_ms = parse_ms
    stats.draw_ms = draw_ms
    stats.text_ms = text_ms

    stem = _stem(path)
    # No drawing is produced here.  The picture is whatever pdflatex and
    # circuitikz render in the browser, so that the page can never show a
    # lookalike of the desktop program's output.
    files = [
        ("tex", f"{stem}.tex", "CircuiTikZ source", tex),
        ("spice", f"{stem}.cir", "SPICE deck", nets["spice"]),
        ("kicad", f"{stem}.net", "KiCad netlist", nets["kicad"]),
        ("text", f"{stem}_netlist.txt", "Readable net table", nets["text"]),
        ("csv", f"{stem}_netlist.csv", "One row per pin", nets["csv"]),
        ("alt", f"{stem}_alt_text.txt", "Description, detailed",
         descriptions["detailed"] + "\n"),
    ]

    payload = {
        "ok": True,
        "stem": stem,
        "source": os.path.basename(path),
        "tex": tex,
        "descriptions": descriptions,
        "netlists": nets,
        "netlist_notes": notes,
        "summary": stats.summary_lines(),
        "warnings": list(graph.warnings),
        "stats": {
            "symbols": stats.symbols,
            "components": stats.components,
            "nets": stats.nets,
            "nodes": stats.nodes,
            "drawn": stats.drawn,
            "described": stats.described,
            "fallbacks": stats.fallbacks,
            "undescribed": stats.undescribed,
            "convert_ms": round(stats.convert_ms, 1),
            "parse_ms": round(parse_ms, 1),
            "draw_ms": round(draw_ms, 1),
            "text_ms": round(text_ms, 1),
        },
        "files": [
            {"key": key, "name": name, "note": note,
             "bytes": len(body if isinstance(body, bytes)
                          else body.encode("utf-8")),
             "binary": isinstance(body, bytes),
             "mime": _MIME.get(name.rsplit(".", 1)[-1], "text/plain")}
            for key, name, note, body in files
        ],
    }

    _LAST = {"stem": stem, "files": files}
    return json.dumps(payload)


def build_zip(pdf: bytes = b"") -> bytes:
    """Return the last conversion's outputs as a ``.zip`` archive.

    *pdf* is the rendering LaTeX produced in the browser; it is passed in
    rather than generated here because only the page can run pdflatex.
    """
    if not _LAST:
        return b""
    buffer = io.BytesIO()
    # A fixed date keeps the archive byte-identical for identical inputs,
    # the way every other SchemAccess output is.
    stamp = (1980, 1, 1, 0, 0, 0)
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
        entries = list(_LAST["files"])
        if pdf:
            entries.insert(0, ("pdf", f"{_LAST['stem']}.pdf",
                               "CircuiTikZ rendering", bytes(pdf)))
        for _key, name, _note, body in entries:
            info = zipfile.ZipInfo(f"{_LAST['stem']}/{name}", date_time=stamp)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            archive.writestr(info, body)
    return buffer.getvalue()

/* Real LaTeX in the browser.

   The desktop program renders its drawing by running pdflatex over the
   generated CircuiTikZ document.  This module does exactly that, using
   pdfTeX compiled to WebAssembly plus the circuitikz package files under
   latex/tex/.  Nothing about the drawing is re-implemented here: the same
   .tex goes in and the same PDF comes out, pixel for pixel.

   It is loaded lazily.  The engine and its TeX tree are about 22 MB, so
   nothing is fetched until a schematic actually needs rendering. */

const LATEX_DIR = "latex/";

let enginePromise = null;

function loadScript(src) {
  return new Promise((resolve, reject) => {
    const tag = document.createElement("script");
    tag.src = src;
    tag.onload = () => resolve();
    tag.onerror = () => reject(new Error(`could not load ${src}`));
    document.head.appendChild(tag);
  });
}

/** Boot pdfTeX once; later calls reuse it. */
async function engine() {
  if (!enginePromise) {
    enginePromise = (async () => {
      await loadScript(`${LATEX_DIR}PdfTeXEngine.js`);
      // eslint-disable-next-line no-undef
      const instance = new exports.PdfTeXEngine();
      await instance.loadEngine();
      // The worker asks for "<endpoint>tex/<name>", so point it at the
      // folder holding the tex tree rather than at the site root.
      instance.setTexliveEndpoint(
        new URL(LATEX_DIR, location.href).href);
      return instance;
    })().catch((error) => {
      enginePromise = null;          // let a later attempt try again
      throw error;
    });
  }
  return enginePromise;
}

/* pdfTeX is one worker and refuses to be re-entered -- calling it while
   it is busy throws "Engine is still spinning".  Requests are therefore
   chained, so dropping a second file or flipping an option mid-render
   waits its turn instead of crashing the engine. */
let queue = Promise.resolve();

async function compile(tex) {
  const instance = await engine();
  instance.writeMemFSFile("main.tex", tex);
  instance.setEngineMainFile("main.tex");
  const result = await instance.compileLaTeX();
  if (!result.pdf) {
    const error = new Error("LaTeX did not produce a PDF");
    error.texLog = result.log || "";
    throw error;
  }
  return new Uint8Array(result.pdf);
}

/**
 * Compile a CircuiTikZ document and return the PDF bytes.
 * Throws with the TeX log attached when the document does not compile.
 *
 * `stillWanted` is consulted once this request reaches the front of the
 * queue.  A render the page has already moved past -- an old file, or the
 * previous state of an option -- returns null rather than spending half a
 * minute producing a PDF nobody will look at.
 */
export function renderPdf(tex, stillWanted) {
  const run = queue.then(
    () => (stillWanted && !stillWanted() ? null : compile(tex)));
  queue = run.then(() => {}, () => {});   // a failure must not stall the chain
  return run;
}

/** True once the engine has been started, so callers can word the wait. */
export function isWarm() {
  return enginePromise !== null;
}

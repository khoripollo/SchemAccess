# SchemAccess Web

A static page that runs the whole converter in the visitor's browser: drop
a `.kicad_sch` file and get the CircuiTikZ LaTeX, the PDF that LaTeX
renders from it, four netlists and a screen-reader description — all as
downloads, with no server involved.

There is no backend, no upload and no account. That is not a limitation
worked around; it is the point. A professor's unmarked coursework never
leaves their machine, and the site can be hosted anywhere that serves
files.

## How it works

Two WebAssembly runtimes, doing the same two jobs the desktop program
does.

`src/schemaccess` is pure Python with no third-party dependencies, so it
runs unmodified in [Pyodide](https://pyodide.org) (CPython compiled to
WebAssembly). The drawing is then produced by real pdfTeX, also compiled
to WebAssembly, running the real `circuitikz` package over the generated
`.tex`. Nothing in either stage was forked or re-implemented in
JavaScript, so the page cannot drift from the program it mirrors.

```
index.html  app.js  styles.css  latex.js       the page
      |                              |
      v                              v
  Pyodide (CPython 3.13)      pdfTeX + circuitikz
  in WebAssembly              in WebAssembly (latex/)
      |                              |
      v                              v
  schemaccess.zip                 the PDF
  -> /schemaccess_pkg
      |
      +-- schemaccess/         the unmodified library
      +-- driver.py            the only browser-specific module
```

`driver.py` exposes three functions to the page:

| Function | Does |
| --- | --- |
| `root_sheet(paths)` | Picks the top sheet of a hierarchical project — the file no other sheet references |
| `convert(path)` | Runs parse → graph → LaTeX → netlists → description and returns one JSON blob |
| `build_zip(pdf)` | Packs the last conversion's files into a `.zip`; the page passes in the PDF, since only it can run pdflatex |

`latex.js` boots the TeX engine on first use and exposes `renderPdf(tex)`.
The rest is plumbing. `app.js` moves dropped files into Pyodide's
filesystem, calls `convert`, hands the `.tex` to `renderPdf`, and renders
the result; downloads are Blobs built from what is already in the page.

## Running it locally

```
python web/build.py                      # refresh schemaccess.zip
python -m http.server 8765 --directory web
```

Then open <http://localhost:8765>. It must be served over HTTP — opening
`index.html` from the filesystem fails, because ES modules and `fetch`
are blocked on `file://`.

## Deploying

The folder is the site; there is no build step at deploy time.

```
netlify deploy --dir=web --prod
```

or drag the `web` folder onto <https://app.netlify.com/drop>. Any static
host works the same way — GitHub Pages, Cloudflare Pages, a departmental
web server.

`netlify.toml` sets a content-security policy that allows exactly three
outbound destinations: the Pyodide runtime on jsDelivr, Google Fonts, and
the Overleaf hand-off that only happens when the reader clicks the button.
The TeX engine and its packages are served from the site itself, so
rendering reaches nothing. Nothing else can leave the page.

**Re-run `python web/build.py` after any change under `src/schemaccess`.**
The zip is a build artefact; the page loads it with
`Cache-Control: must-revalidate` so a deploy is picked up immediately.

## What the visitor gets

| File | Contents |
| --- | --- |
| `<name>.pdf` | The circuitikz rendering, compiled in the browser by pdfTeX |
| `<name>.tex` | Standalone CircuiTikZ document; compiles with `pdflatex` |
| `<name>.cir` | ngspice / LTspice deck, ground on node `0` |
| `<name>.net` | KiCad's own S-expression netlist |
| `<name>_netlist.txt` | Net table written to be read aloud |
| `<name>_netlist.csv` | One row per pin, for a spreadsheet |
| `<name>_alt_text.txt` | The description at the chosen detail level |

The page never draws a schematic itself. What it shows in the preview is
the compiled PDF and nothing else — the same file the desktop program
produces from the same `.tex`, verified pixel for pixel. The library's
own `svgpreview` and `pdfwriter` modules still exist and the command-line
tool still uses them when no LaTeX toolchain is installed, but they are
not reachable from the web page.

## Options

One, matching the desktop program's checkbox of the same name: **Show
junction dots**, the filled dot KiCad draws where three or more wires
meet. Turning it off re-runs the conversion and recompiles, because the
dots are drawn by circuitikz and only a new `.tex` can remove them. It
changes the picture and the `.tex` and nothing else — the netlists, the
description and the net and node counts are byte-identical either way.

## Limits worth knowing

- **The first visit downloads two runtimes.** Pyodide is roughly 10 MB
  from a CDN; the TeX engine, format file and packages are about 22 MB
  from the site itself. Both are then cached, and the page works offline.
- **The first render takes about a minute**, most of it starting pdfTeX.
  Later schematics in the same session take around half that, because the
  engine stays warm.
- **Hierarchical projects need every sheet.** Drop the whole folder, or a
  `.zip` of it; sub-sheets are matched by file name, so a flat archive is
  fine.
- **KiCad 6 or newer.** Legacy `.sch` files from KiCad 5 and earlier are a
  different format; open and re-save the project in a current KiCad first.

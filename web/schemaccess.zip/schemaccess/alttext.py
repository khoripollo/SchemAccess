"""Alt-text generator: natural-language circuit descriptions.

Turns a :class:`~schemaccess.model.CircuitGraph` into structured prose for
blind and low-vision readers.  Three detail levels are supported:

* ``short``    - element/node counts plus a one-sentence component list;
* ``standard`` - counts, parallel groups, series chains, remaining
  connections and source polarity;
* ``detailed`` - everything in standard plus detected structures (dividers,
  filters, bridges, op-amp configurations, logic gates, power rails), a
  per-component connection listing and any graph warnings.

Output is deterministic: identical graphs always yield identical text.
Sentences are emitted one per line with no trailing whitespace.
"""

from __future__ import annotations

import re
from typing import Dict, List, Optional, Sequence, Tuple

from . import analyzer
from .loops import find_meshes, same_way
from .model import (CircuitGraph, Component, ComponentType, NetKind,
                    PinConnection)
from .netbuilder import node_names

# ---------------------------------------------------------------------------
# Value formatting
# ---------------------------------------------------------------------------

_UNIT_FOR_TYPE: Dict[ComponentType, str] = {
    ComponentType.RESISTOR: "ohm",
    ComponentType.POTENTIOMETER: "ohm",
    ComponentType.CAPACITOR: "farad",
    ComponentType.CAPACITOR_POLARIZED: "farad",
    ComponentType.INDUCTOR: "henry",
    ComponentType.VOLTAGE_SOURCE: "volt",
    ComponentType.BATTERY: "volt",
    ComponentType.AC_SOURCE: "volt",
    ComponentType.CURRENT_SOURCE: "ampere",
}

# Metric prefixes.  Only 'm' vs 'M' is case-sensitive (milli vs mega);
# every other letter is accepted in either case.
_PREFIX_WORDS = {"T": "tera", "G": "giga", "K": "kilo",
                 "U": "micro", "µ": "micro", "N": "nano", "P": "pico"}

# Unit tokens that may trail the value string; longest first so that
# 'ohm' wins over the single letter forms.
_UNIT_TOKENS = ("ohms", "ohm", "farads", "farad", "henries", "henry",
                "volts", "volt", "amperes", "ampere", "amps", "amp",
                "Ω", "F", "H", "V", "A", "R")

_NUMBER_RE = re.compile(r"^(\d+(?:[.,]\d+)?|[.,]\d+)\s*(.*)$")
_RKM_RE = re.compile(r"^([A-Za-zµΩ]+)(\d+)$")

# Phasors in polar form: "10<90", "10@90", "10 angle -45deg".  KiCad users
# typically type the Unicode angle sign; '<' and '@' are common ASCII
# stand-ins.
#: Joins a magnitude to its phase angle.  Kept as a constant so the phrase
#: can be split back off when it reads better after the component name.
_ANGLE_PHRASE = " at an angle of "

_POLAR_RE = re.compile(
    r"^(.*?)\s*(?:∠|<|@|\bangle\b)\s*([+-]?\d+(?:[.,]\d+)?\s*°?)\s*"
    r"(?:deg|degs|degrees?)?$",
    re.IGNORECASE)


def _prefix_word(token: str) -> Optional[str]:
    """Return the prefix word for a metric-prefix token ('' for none)."""
    token = token.strip()
    if token == "":
        return ""
    if token.upper() == "MEG":
        return "mega"
    if len(token) == 1:
        if token == "m":
            return "milli"
        if token == "M":
            return "mega"
        return _PREFIX_WORDS.get(token.upper())
    return None


def format_value(value: str, ctype: ComponentType) -> Optional[str]:
    """Turn a KiCad value string into words, using *ctype* for the unit.

    Examples: ``'100'`` (resistor) -> ``'100 Ohm'``; ``'4.7k'`` ->
    ``'4.7 kiloohm'``; ``'22nF'`` -> ``'22 nanofarad'``; ``'5V'`` ->
    ``'5 Volt'``; ``'1MEG'`` -> ``'1 megaohm'``; ``'4k7'`` ->
    ``'4.7 kiloohm'``.  Phasors written in polar form (``'10<90'``,
    ``'10@90'``) become ``'10 Volt at an angle of 90 degrees'``.  Returns
    ``None`` when the component type has no natural unit or the value is
    missing/placeholder ('R', 'C', '~', '?', '') or unparseable, so callers
    can simply omit it.
    """
    unit = _UNIT_FOR_TYPE.get(ctype)
    if unit is None:
        return None
    text = (value or "").strip()
    if not text or not any(ch.isdigit() for ch in text):
        return None

    polar = _POLAR_RE.match(text)
    if polar is not None:
        magnitude = format_value(polar.group(1), ctype)
        if magnitude is None:
            return None
        angle = polar.group(2).replace(",", ".").rstrip("°").strip()
        degrees = "degree" if angle in ("1", "-1") else "degrees"
        return f"{magnitude}{_ANGLE_PHRASE}{angle} {degrees}"
    match = _NUMBER_RE.match(text)
    if match is None:
        return None
    number = match.group(1).replace(",", ".")
    if number.startswith("."):
        number = "0" + number
    rest = match.group(2).strip()

    rkm = _RKM_RE.match(rest)
    if rkm is not None:
        letter, fraction = rkm.groups()
        prefix = "" if letter in ("R", "r", "Ω") else _prefix_word(letter)
        if prefix is None:
            return None
        number = f"{number}.{fraction}"
    else:
        prefix = None
        for token in _UNIT_TOKENS:
            if rest.lower().endswith(token.lower()):
                candidate = _prefix_word(rest[:len(rest) - len(token)])
                if candidate is not None:
                    prefix = candidate
                    break
        if prefix is None:
            prefix = _prefix_word(rest)
        if prefix is None:
            return None

    if prefix == "":
        return f"{number} {unit.capitalize()}"
    return f"{number} {prefix}{unit}"


# ---------------------------------------------------------------------------
# Phrase helpers
# ---------------------------------------------------------------------------

# First words that take 'an' despite starting with a consonant letter.
_AN_FIRST_WORDS = {"LED", "NPN", "N-channel", "XOR", "XNOR", "RC", "RL"}

# Words that start with a vowel letter but a consonant *sound*, so they
# take 'a': "a unijunction transistor", not "an unijunction transistor".
_A_FIRST_PREFIXES = ("uni", "use", "uti", "eu")


def _article(phrase: str) -> str:
    """Choose 'a' or 'an' for *phrase*."""
    first = phrase.split()[0] if phrase.split() else phrase
    if first in _AN_FIRST_WORDS:
        return "an"
    if first.lower().startswith(_A_FIRST_PREFIXES):
        return "a"
    if phrase[:1] in "aeiouAEIOU8":
        return "an"
    return "a"


def _join(items: Sequence[str]) -> str:
    """Join a list into English prose: 'a', 'a and b', 'a, b and c'."""
    items = list(items)
    if not items:
        return ""
    if len(items) == 1:
        return items[0]
    return ", ".join(items[:-1]) + " and " + items[-1]


def _cap(sentence: str) -> str:
    """Upper-case the first character without touching the rest."""
    return sentence[:1].upper() + sentence[1:] if sentence else sentence


def _pin_key(number: str) -> Tuple[int, int, str]:
    return (0, int(number), number) if number.isdigit() else (1, 0, number)


_PLACEHOLDER_PIN_NAMES = {"", "~", "?"}


def _component_phrase(comp: Component) -> str:
    """'a 100 Ohm resistor labelled R2' / 'a resistor labelled R3'.

    A phase angle is moved after the reference, so a phasor reads as
    'a 10 Volt AC voltage source labelled V1 at an angle of 90 degrees'
    rather than jamming the angle between the magnitude and the type.
    """
    formatted = format_value(comp.value, comp.ctype)
    angle_suffix = ""
    if formatted and _ANGLE_PHRASE in formatted:
        formatted, angle = formatted.split(_ANGLE_PHRASE, 1)
        angle_suffix = f"{_ANGLE_PHRASE}{angle}"
    type_word = comp.ctype.value
    core = f"{formatted} {type_word}" if formatted else type_word
    return f"{_article(core)} {core} labelled {comp.ref}{angle_suffix}"


#: Types whose dot marks winding phase rather than terminal polarity.
_WINDING_TYPES = (ComponentType.INDUCTOR, ComponentType.TRANSFORMER)

#: Terminal names for three-terminal devices, by pin name.
_BJT_TERMINALS = {"C": "collector", "B": "base", "E": "emitter"}
_FET_TERMINALS = {"D": "drain", "G": "gate", "S": "source"}
_UJT_TERMINALS = {"E": "emitter", "B1": "base 1", "B2": "base 2"}


def _pin_label(comp: Component, pin: PinConnection) -> str:
    """Human name for a pin, with no leading article.

    The caller supplies 'the', so the same label works in a sentence
    ("...with the collector connected to...") and in the exhaustive pin
    listing, where a bare noun reads better.
    """
    name = pin.name.strip()
    upper = name.upper()
    if comp.ctype.is_transistor:
        if comp.ctype == ComponentType.UJT:
            table = _UJT_TERMINALS
        elif comp.ctype in (ComponentType.TRANSISTOR_NPN,
                            ComponentType.TRANSISTOR_PNP):
            table = _BJT_TERMINALS
        else:
            table = _FET_TERMINALS
        if upper in table:
            return table[upper]
    if comp.ctype == ComponentType.TRANSFORMER and len(upper) == 2:
        winding = {"A": "primary", "S": "secondary"}.get(upper[0])
        if winding:
            end = "start" if upper[1] == "A" else "end"
            return f"{end} of the {winding} winding"
    if comp.ctype == ComponentType.OPAMP:
        if upper in ("V+", "VS+", "VCC", "VDD"):
            return "positive supply pin"
        if upper in ("V-", "VS-", "VSS", "VEE"):
            return "negative supply pin"
        if "-" in name:
            return "inverting input"
        if "+" in name:
            return "non-inverting input"
        if pin.etype == "output" or "OUT" in upper:
            return "output"
    if name not in _PLACEHOLDER_PIN_NAMES:
        return f"pin {pin.number} ({name})"
    return f"pin {pin.number}"


def _distinct_nets(comp: Component) -> List[int]:
    return sorted({p.net_id for p in comp.pins.values() if p.net_id >= 0})


#: Pin labels that carry no information once the pin is left unconnected.
_OPTIONAL_PIN_LABELS = ("positive supply pin", "negative supply pin")


def _the(label: str) -> str:
    """Prefix a pin label with 'the', except where it reads wrongly.

    A numbered terminal is named like a proper noun - "base 1", "pin 4" -
    and takes no article.
    """
    if label.startswith("pin ") or label[-1:].isdigit():
        return label
    return f"the {label}"


def _join_oxford(items: Sequence[str]) -> str:
    """Join with a serial comma: 'a, b, and c'.

    Used where a sentence lists a device's terminals: the extra comma
    keeps the final clause from running into the previous one when the
    clauses are themselves long.
    """
    items = list(items)
    if len(items) <= 2:
        return _join(items)
    return ", ".join(items[:-1]) + ", and " + items[-1]


def _is_dangling(graph: CircuitGraph, pin: PinConnection) -> bool:
    """True when nothing else in the schematic shares this pin's net."""
    if pin.net_id < 0:
        return True
    net = graph.nets[pin.net_id]
    return net.kind == NetKind.ANONYMOUS and len(net.pins) <= 1


# ---------------------------------------------------------------------------
# Section builders
# ---------------------------------------------------------------------------

def _counts_sentence(graph: CircuitGraph) -> str:
    n_elements = len(graph.components)
    n_nodes = sum(1 for net in graph.nets
                  if len(net.pins) >= 2
                  or (net.kind == NetKind.GROUND and net.pins))
    verb = "is" if n_elements == 1 else "are"
    element_word = "element" if n_elements == 1 else "elements"
    node_word = "node" if n_nodes == 1 else "nodes"
    return (f"There {verb} {n_elements} {element_word} and {n_nodes} "
            f"{node_word} in the circuit.")


def _chain_layout(graph: CircuitGraph, chain: List[str]
                  ) -> Tuple[Optional[int], Optional[int], List[int]]:
    """Boundary nets and internal nets of a series chain, in chain order.

    Returns ``(None, None, internals)`` for a closed loop.
    """
    net_sets = [set(_distinct_nets(graph.components[r])) for r in chain]
    internals: List[int] = []
    for i in range(len(chain) - 1):
        shared = sorted(net_sets[i] & net_sets[i + 1])
        internals.append(shared[0] if shared else -1)
    if len(chain) >= 3:
        closing = sorted((net_sets[0] & net_sets[-1]) - set(internals))
        if closing:
            return None, None, internals + [closing[0]]
    first = sorted(net_sets[0] - {internals[0]})
    last = sorted(net_sets[-1] - {internals[-1]})
    first_outer = first[0] if first else internals[0]
    last_outer = last[0] if last else internals[-1]
    return first_outer, last_outer, internals


def _standard_lines(graph: CircuitGraph,
                    analysis: "analyzer.CircuitAnalysis",
                    nname) -> List[str]:
    lines = [_counts_sentence(graph)]
    covered = set()

    # Devices with more than two terminals come first: they are what the
    # circuit is built around, so naming them before the passive groups
    # gives a listener the shape of the circuit before the detail.  A
    # device already inside a parallel or series group is left to that
    # group's own sentence.
    grouped = {r for g in analysis.parallel_groups for r in g}
    grouped |= {r for c in analysis.series_chains for r in c}
    for comp in graph.sorted_components():
        if comp.ctype.is_two_terminal or comp.ref in grouped:
            continue
        covered.add(comp.ref)
        parts = []
        for key in sorted(comp.pins, key=_pin_key):
            pin = comp.pins[key]
            label = _pin_label(comp, pin)
            # Supply rails are routinely left off a schematic sheet.
            # Announcing one as "connected to an unconnected point" is
            # noise to a listener; the exhaustive pin listing in the
            # detailed output still records it.
            if label in _OPTIONAL_PIN_LABELS and _is_dangling(graph, pin):
                continue
            parts.append(f"{_the(label)} connected to {nname(pin.net_id)}")
        core = comp.ctype.value
        if parts:
            lines.append(f"{comp.ref} is {_article(core)} {core} with "
                         f"{_join_oxford(parts)}.")
        else:
            lines.append(f"{comp.ref} is {_article(core)} {core} with no "
                         f"connected pins.")

    # Parallel groups.
    for group in analysis.parallel_groups:
        comps = [graph.components[r] for r in group]
        nets = _distinct_nets(comps[0])
        between = f"Between {nname(nets[0])} and {nname(nets[1])}"
        phrases = [_component_phrase(c) for c in comps]
        if len(phrases) == 2:
            lines.append(f"{between}, {phrases[0]} is connected in "
                         f"parallel with {phrases[1]}.")
        else:
            lines.append(f"{between}, {_join(phrases)} are connected "
                         f"in parallel.")
        covered.update(group)

    # Then series chains.
    for chain in analysis.series_chains:
        comps = [graph.components[r] for r in chain]
        phrases = [_component_phrase(c) for c in comps]
        first_outer, last_outer, internals = _chain_layout(graph, chain)
        joined_nodes = _join([nname(n) for n in internals])
        if first_outer is None:
            lines.append(f"{_cap(_join(phrases))} are connected in a "
                         f"series loop, joined at {joined_nodes}.")
        else:
            lines.append(f"Between {nname(first_outer)} and "
                         f"{nname(last_outer)}, {phrases[0]} is connected "
                         f"in series with {_join(phrases[1:])}, these "
                         f"elements are connected at {joined_nodes}.")
        covered.update(chain)

    # Remaining components.
    for comp in graph.sorted_components():
        if comp.ref in covered:
            continue
        nets = _distinct_nets(comp)
        if len(nets) == 2:
            lines.append(f"Between {nname(nets[0])} and {nname(nets[1])} "
                         f"there is {_component_phrase(comp)}.")
        elif len(nets) == 1:
            lines.append(f"{_cap(_component_phrase(comp))} has both "
                         f"terminals connected to {nname(nets[0])}.")
        else:
            lines.append(f"{_cap(_component_phrase(comp))} is not "
                         f"connected to anything.")

    # Source polarity sentences.
    sources = [c for c in graph.sorted_components() if c.ctype.is_source]
    for comp in sources:
        pins = [comp.pins[k] for k in sorted(comp.pins, key=_pin_key)]
        pos = next((p for p in pins if "+" in p.name), None)
        if pos is None:
            pos = next((p for p in pins if p.number == "1"), None)
        neg = next((p for p in pins if "-" in p.name and p is not pos), None)
        if neg is None:
            neg = next((p for p in pins if p is not pos), None)
        if pos is None or neg is None:
            continue
        label = "" if len(sources) == 1 else f" labelled {comp.ref}"
        lines.append(f"The positive terminal of the {comp.ctype.value}"
                     f"{label} is connected to {nname(pos.net_id)} and the "
                     f"negative terminal is connected to "
                     f"{nname(neg.net_id)}.")
    return lines


def _short_lines(graph: CircuitGraph) -> List[str]:
    lines = [_counts_sentence(graph)]
    comps = graph.sorted_components()
    if comps:
        phrases = [_component_phrase(c) for c in comps]
        lines.append(f"The circuit contains {_join(phrases)}.")
    else:
        lines.append("The circuit contains no components.")
    return lines


_DETAILED_STRUCTURE_KINDS = (
    "voltage_divider", "rc_low_pass", "rc_high_pass",
    "rl_low_pass", "rl_high_pass", "wheatstone",
    "opamp_inverting", "opamp_non_inverting", "opamp_follower",
    "opamp_positive_feedback", "logic")


def _detailed_lines(graph: CircuitGraph,
                    analysis: "analyzer.CircuitAnalysis",
                    nname) -> List[str]:
    lines = _standard_lines(graph, analysis, nname)

    extras = [s for s in analysis.structures
              if s.kind in _DETAILED_STRUCTURE_KINDS]
    if extras or analysis.power_rails:
        lines.append("Detected structures:")
        for structure in extras:
            lines.append(structure.description)
        if analysis.power_rails:
            rail_word = ("Power rail" if len(analysis.power_rails) == 1
                         else "Power rails")
            lines.append(f"{rail_word}: {_join(analysis.power_rails)}.")

    if graph.components:
        lines.append("Connections by component:")
        for comp in graph.sorted_components():
            parts = []
            for key in sorted(comp.pins, key=_pin_key):
                pin = comp.pins[key]
                name = pin.name.strip()
                tag = (f"pin {pin.number} ({name})"
                       if name not in _PLACEHOLDER_PIN_NAMES
                       else f"pin {pin.number}")
                parts.append(f"{tag} to {nname(pin.net_id)}")
            listing = "; ".join(parts) if parts else "no pins"
            lines.append(f"{comp.ref}: {listing}.")

    # A polarity dot is information a sighted reader gets for free from the
    # drawing, so it has to be stated for a screen-reader user.
    # A transistor's filled circle is body art - KiCad fills the point
    # where a MOSFET's bulk meets its source - so it says nothing about
    # polarity and must not be announced as if it did.
    dotted = [c for c in graph.sorted_components()
              if c.dots and not c.ctype.is_transistor]
    if dotted:
        for comp in dotted:
            marker = ("winding-phase dot" if comp.ctype in _WINDING_TYPES
                      else "polarity dot")
            lines.append(
                f"The {comp.ctype.value} labelled {comp.ref} is marked with "
                f"a {marker}.")

    # Free text on the sheet - "a", "b", "t = 0" beside a switch - is
    # part of the question being asked, and a listener gets it from
    # nowhere else.
    doc = graph.document
    notes = [item.text.strip() for item in (doc.texts if doc else [])
             if item.text.strip()]
    if notes:
        lines.append("Text written on the schematic: "
                     + _join([f"'{note}'" for note in notes]) + ".")

    messages = list(analysis.notes) + list(graph.warnings)
    if messages:
        lines.append("Warnings:")
        lines.extend(messages)
    return lines


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def _loop_lines(graph: CircuitGraph, level: str) -> List[str]:
    found = find_meshes(graph)
    if not found.ok:
        return [f"Loop currents are not shown: {found.reason}."]
    names = [mesh.name for mesh in found.meshes]
    if len(names) == 1:
        lines = [f"The drawing marks one loop current for mesh analysis, "
                 f"{names[0]}, drawn the way its current flows."]
    else:
        lines = [f"The drawing marks {len(names)} loop currents for mesh "
                 f"analysis, {_join(names)}, each drawn the way its current "
                 f"flows."]
    if level == "short":
        return lines
    for mesh in found.meshes:
        lines.append(f"{mesh.name} flows {mesh.sense} through "
                     f"{_join(mesh.refs)}.")
    for ref, first, second in found.shared():
        if same_way(first, second):
            lines.append(f"{ref} is shared by {first.name} and "
                         f"{second.name}, which pass through it the same "
                         f"way, so its current is {first.name} plus "
                         f"{second.name}.")
        else:
            lines.append(f"{ref} is shared by {first.name} and "
                         f"{second.name}, which pass through it opposite "
                         f"ways, so its current is {first.name} minus "
                         f"{second.name}, taken in the direction of "
                         f"{first.name}.")
    return lines


def generate(graph: CircuitGraph, detail: str = "standard",
             loops: bool = False) -> str:
    """Return a structured natural-language description of *graph*.

    *detail* is one of ``short``, ``standard``, ``detailed`` (anything
    else falls back to ``standard``).  Output is deterministic for identical inputs; sentences are separated
    by newlines and carry no trailing whitespace.
    """
    level = (detail or "standard").strip().lower()
    names = node_names(graph)

    def nname(net_id: int) -> str:
        if net_id < 0:
            return "an unconnected point"
        return names.get(net_id, "an unconnected point")

    if level == "short":
        lines = _short_lines(graph)
    elif level == "detailed":
        analysis = analyzer.analyze(graph)
        lines = _detailed_lines(graph, analysis, nname)
    else:
        analysis = analyzer.analyze(graph)
        lines = _standard_lines(graph, analysis, nname)
    if loops:
        at = lines.index("Warnings:") if "Warnings:" in lines else len(lines)
        lines[at:at] = _loop_lines(graph, level)
    return "\n".join(line.rstrip() for line in lines)
